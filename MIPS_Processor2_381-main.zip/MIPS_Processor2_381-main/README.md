# MIPS_Processor2_381
A 5 stage pipelined processor that can execute basic MIPS instructions.
